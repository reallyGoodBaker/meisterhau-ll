import { DefaultTrickModule } from '../basic/default';
declare class EmptyHandTricks extends DefaultTrickModule {
    constructor();
}
export declare const tricks: EmptyHandTricks;
export {};
