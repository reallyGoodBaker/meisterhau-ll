import { DefaultTrickModule } from "../basic/default";
declare class DoubleBlade extends DefaultTrickModule {
    constructor();
}
export declare const tricks: DoubleBlade;
export {};
