import { DefaultTrickModule } from '../basic/default';
declare class ShieldSwordTricks extends DefaultTrickModule {
    constructor();
}
export declare const tricks: ShieldSwordTricks;
export {};
