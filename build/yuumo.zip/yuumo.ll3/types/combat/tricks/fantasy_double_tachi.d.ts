import { DefaultTrickModule } from "@combat/basic/default";
declare class FantasyDoubleTachiTricks extends DefaultTrickModule {
    constructor();
}
export declare const tricks: FantasyDoubleTachiTricks;
export {};
