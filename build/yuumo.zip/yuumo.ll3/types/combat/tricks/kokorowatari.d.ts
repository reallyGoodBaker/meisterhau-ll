import { DefaultTrickModule } from "@combat/basic/default";
declare class Kokorowatari extends DefaultTrickModule {
    constructor();
}
export declare const tricks: Kokorowatari;
export {};
