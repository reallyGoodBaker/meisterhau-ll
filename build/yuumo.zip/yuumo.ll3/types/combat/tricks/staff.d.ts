import { DefaultTrickModule } from "combat/basic/default";
declare class StaffModule extends DefaultTrickModule {
    constructor();
}
export declare const tricks: StaffModule;
export {};
