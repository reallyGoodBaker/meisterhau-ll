export const tricks: DoubleDaggerTricks;
declare class DoubleDaggerTricks extends DefaultTrickModule {
    constructor();
}
import { DefaultTrickModule } from "../basic/default";
export {};
