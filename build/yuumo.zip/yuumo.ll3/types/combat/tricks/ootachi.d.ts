import { DefaultTrickModule } from '../basic/default';
declare class OotachiTricks extends DefaultTrickModule {
    constructor();
}
export declare const tricks: OotachiTricks;
export {};
