export const tricks: MoonGlaiveTricks;
declare class MoonGlaiveTricks extends DefaultTrickModule {
    constructor();
}
import { DefaultTrickModule } from "../basic/default";
export {};
