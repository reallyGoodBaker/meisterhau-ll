import { DefaultTrickModule } from '../basic/default';
declare class UchigatanaModule extends DefaultTrickModule {
    constructor();
}
export declare const tricks: UchigatanaModule;
export {};
