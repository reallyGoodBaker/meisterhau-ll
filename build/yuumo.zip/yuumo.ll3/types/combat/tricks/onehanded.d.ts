import { DefaultTrickModule } from "@combat/basic/default";
declare class OneHandedSword extends DefaultTrickModule {
    constructor();
}
export declare const tricks: OneHandedSword;
export {};
