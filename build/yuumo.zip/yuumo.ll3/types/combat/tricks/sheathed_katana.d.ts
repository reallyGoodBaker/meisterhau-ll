export const tricks: TrickModule;
