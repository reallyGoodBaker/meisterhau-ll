import { DefaultTrickModule } from "@combat/basic/default";
declare class DoubleAxeTrick extends DefaultTrickModule {
    constructor();
}
export declare const tricks: DoubleAxeTrick;
export {};
