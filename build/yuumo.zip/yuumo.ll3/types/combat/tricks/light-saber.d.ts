export const tricks: LightSaberTrick;
declare class LightSaberTrick extends DefaultTrickModule {
    constructor();
}
import { DefaultTrickModule } from "../basic/default";
export {};
