export function movement(pl: any, enabled?: boolean): void;
export function camera(pl: any, enabled?: boolean): void;
export function movementInput(pl: any, enabled?: boolean): void;
