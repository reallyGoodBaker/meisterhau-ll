/**
 * 创建二维向量
 * @param {number} x1 起点x坐标
 * @param {number} y1 起点y坐标
 * @param {number} x2 终点x坐标
 * @param {number} y2 终点y坐标
 * @returns {{dx: number, dy: number, m: number}} 向量对象
 */
export function vec2(x1: number, y1: number, x2: number, y2: number): {
    dx: number;
    dy: number;
    m: number;
};
/**
 * 计算两个向量之间的夹角
 * @param {{dx: number, dy: number, m: number}} v1 第一个向量
 * @param {{dx: number, dy: number, m: number}} v2 第二个向量
 * @returns {number} 夹角（弧度）
 */
export function getAngleFromVector2(v1: {
    dx: number;
    dy: number;
    m: number;
}, v2: {
    dx: number;
    dy: number;
    m: number;
}): number;
/**
 * 旋转二维向量
 * @param {{dx: number, dy: number, m: number}} v 原始向量
 * @param {number} rad 旋转角度（弧度）
 * @returns {{dx: number, dy: number, m: number}} 旋转后的向量
 */
export function rotate2(v: {
    dx: number;
    dy: number;
    m: number;
}, rad: number): {
    dx: number;
    dy: number;
    m: number;
};
/**
 * 缩放二维向量
 * @param {{dx: number, dy: number, m: number}} v 原始向量
 * @param {number} factor 缩放因子
 * @returns {{dx: number, dy: number, m: number}} 缩放后的向量
 */
export function multiply2(v: {
    dx: number;
    dy: number;
    m: number;
}, factor: number): {
    dx: number;
    dy: number;
    m: number;
};
/**
 * 向量减法
 * @param {{dx: number, dy: number, m: number}} a 被减向量
 * @param {{dx: number, dy: number, m: number}} b 减向量
 * @returns {{dx: number, dy: number, m: number}} 差向量
 */
export function minus(a: {
    dx: number;
    dy: number;
    m: number;
}, b: {
    dx: number;
    dy: number;
    m: number;
}): {
    dx: number;
    dy: number;
    m: number;
};
/**
 * 将向量转换为角度
 * @param {{dx: number, dy: number, m: number}} v 向量
 * @returns {number} 角度（弧度）
 */
export function vec2ToAngle(v: {
    dx: number;
    dy: number;
    m: number;
}): number;
