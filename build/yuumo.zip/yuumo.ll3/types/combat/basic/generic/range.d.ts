import { Actor } from '@utils/actor';
/** 默认攻击范围配置 */
export declare const defaultRange: {
    angle: number;
    rotation: number;
    radius: number;
};
/**
 * 从扇形区域选择目标
 * @param pl 源角色
 * @param range 攻击范围配置
 * @returns 在扇形区域内的目标角色数组
 */
export declare function selectFromSector(pl: Actor, range?: AttackRange): Actor[];
