import { Actor } from "@utils/actor";
/**
 * 设置相机输入权限
 * @param pl 玩家对象
 * @param enabled 是否启用相机输入
 */
export declare const cameraInput: (pl: Player, enabled?: boolean) => void;
/**
 * 清除相机设置，恢复默认相机
 * @param pl 玩家对象
 */
export declare function clearCamera(pl: Player): void;
/**
 * 设置战斗相机到中间点位置
 * @param pl 玩家对象
 * @param en 目标角色
 */
export declare const battleCameraMiddlePoint: (pl: Player, en: Actor) => void;
/**
 * 设置战斗相机
 * @param pl 玩家对象
 * @param en 目标角色
 */
export declare const battleCamera: (pl: Player, en: Actor) => void;
