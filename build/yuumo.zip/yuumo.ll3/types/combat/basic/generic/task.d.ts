/**
 * 任务类 - 用于管理异步任务队列
 */
export class Task {
    /**
     * 获取或创建任务实例
     * @param {string} uniqueId 唯一标识符
     * @returns {Task} 任务实例
     */
    static get(uniqueId: string): Task;
    /**
     * 构造函数
     * @param {string} uniqueId 唯一标识符
     */
    constructor(uniqueId: string);
    /** 任务队列 */
    _queue: any[];
    /** 当前任务的时间戳 */
    _currentTimeStamp: null;
    /**
     * 批量添加任务到队列
     * @param {{handler: () => any, timeout: number}[]} taskList 任务列表
     * @returns {Task} 当前任务实例（支持链式调用）
     */
    queueList(taskList: {
        handler: () => any;
        timeout: number;
    }[]): Task;
    /**
     * 添加单个任务到队列
     * @param {() => any} handler 任务处理函数
     * @param {number} timeout 任务延迟时间（毫秒）
     * @returns {Task} 当前任务实例（支持链式调用）
     */
    queue(handler: () => any, timeout?: number): Task;
    /**
     * 跳过当前正在执行的任务
     */
    skip(): void;
    /**
     * 取消所有任务
     */
    cancel(): void;
    /**
     * 开始执行任务队列
     */
    run(): void;
    #private;
}
