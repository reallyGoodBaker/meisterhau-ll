/**
 * 设置角色速度
 * @param {Actor} pl 角色对象
 * @param {number} rotation 旋转角度（相对于角色朝向）
 * @param {number} h 水平速度
 * @param {number} v 垂直速度
 */
export function setVelocity(pl: Actor, rotation: number, h: number, v: number): void;
/**
 * 检查角色是否与方块碰撞
 * @param {Actor} pl 角色对象
 * @returns {boolean} 是否发生碰撞
 */
export function isCollide(pl: Actor): boolean;
