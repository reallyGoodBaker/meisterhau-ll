import { Optional } from '@utils/optional';
import { Actor } from '@utils/actor';
import { EventEmitter } from '../../../events';
/**
 * 锁定目标
 * @param src 源玩家ID
 * @param target 目标角色
 */
export declare function lockTarget(src: string, target: Actor): void;
/**
 * 释放目标锁定
 * @param src 源玩家ID
 */
export declare function releaseTarget(src: string): void;
/**
 * 切换锁定状态
 * @param src 源玩家ID
 * @returns 目标角色或null/false
 */
export declare function toggleLock(src: string): false | null;
/**
 * 计算两个角色之间的角度
 * @param actor 源角色
 * @param actor2 目标角色
 * @returns [水平角度, 垂直角度]
 */
export declare function getAngle(actor: Actor, actor2: Actor): number[];
/**
 * 让角色看向目标
 * @param actor 源角色
 * @param target 目标角色
 */
export declare function lookAt(actor: Actor, target: Actor): void;
/**
 * 从锁定组件获取目标角色
 * @param actor 源角色
 * @returns 目标角色的Optional包装
 */
export declare function getTargetFromLock(actor: Actor): Optional<Actor>;
/**
 * 让角色看向锁定的目标
 * @param pl 源角色
 */
export declare function lookAtTarget(pl: Actor): void;
/**
 * 检查角色是否有锁定目标
 * @param pl 源角色
 * @returns 是否有锁定目标
 */
export declare function hasLock(pl: Actor): boolean;
/**
 * 吸附到目标角色
 * @param pl 源角色
 * @param en 目标角色
 * @param max 最大吸附距离
 * @param offset 偏移距离
 */
export declare function adsorbTo(pl: Actor, en: Actor, max: number, offset?: number): void;
/**
 * 吸附到锁定的目标
 * @param pl 源角色
 * @param max 最大吸附距离
 * @param offset 偏移距离
 */
export declare function adsorbToTarget(pl: Actor, max: number, offset: number): void;
/**
 * 吸附到目标或设置速度
 * @param pl 源角色
 * @param max 最大距离/速度
 * @param velocityRot 速度角度
 * @param offset 偏移距离
 */
export declare function adsorbOrSetVelocity(pl: Actor, max: number, velocityRot?: number, offset?: number): void;
/**
 * 计算到锁定目标的距离
 * @param pl 源角色
 * @returns 到目标的距离，无目标时返回Infinity
 */
export declare function distanceToTarget(pl: Actor): number;
/**
 * 每tick更新锁定状态
 * @param em 事件发射器
 * @returns 更新函数
 */
export declare const onTick: (em: EventEmitter) => () => void;
/**
 * 获取最近的实体
 * @param en 源角色
 * @returns 最近的实体或null
 */
export declare function getClosedEntity(en: Actor): null;
