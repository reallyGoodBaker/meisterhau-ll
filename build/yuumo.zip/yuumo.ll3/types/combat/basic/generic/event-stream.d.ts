/**
 * 事件输入流类 - 用于过滤和转发事件
 */
export class EventInputStream {
    /** 静态映射表，存储事件发射器到输入流的映射 */
    static "__#5@#ends": Map<any, any>;
    /**
     * 获取或创建事件输入流实例
     * @param {EventEmitter} end 事件发射器
     * @returns {EventInputStream} 事件输入流实例
     */
    static get(end: EventEmitter): EventInputStream;
    /**
     * 构造函数
     * @param {EventEmitter} end 事件发射器
     */
    constructor(end: EventEmitter);
    /**
     * 添加事件过滤器
     * @param {(val: {type: string; args: any[]}) => boolean} filter 过滤器函数
     */
    addFilter(filter: (val: {
        type: string;
        args: any[];
    }) => boolean): void;
    /**
     * 移除事件过滤器
     * @param {(val: {type: string; args: any[]}) => boolean} filter 过滤器函数
     */
    removeFilter(filter: (val: {
        type: string;
        args: any[];
    }) => boolean): void;
    /**
     * 设置目标事件发射器
     * @param {EventEmitter} end 事件发射器
     */
    setEnd(end: EventEmitter): void;
    /**
     * 推送事件到输入流
     * @param {string} type 事件类型
     * @param {any[]} args 事件参数
     */
    put(type: string, args: any[]): void;
    #private;
}
import { EventEmitter } from "../../../events";
