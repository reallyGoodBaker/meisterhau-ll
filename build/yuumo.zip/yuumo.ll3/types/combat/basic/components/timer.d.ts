import { BaseComponent } from "../core/component";
/** 计时器组件 - 倒计时功能 */
export declare class Timer extends BaseComponent {
    /** 计时器总时长 */
    readonly duration: number;
    /** 剩余时间 */
    rest: number;
    /** 是否完成计时 */
    get done(): boolean;
    constructor(
    /** 计时器总时长 */
    duration?: number);
    /** 每tick减少剩余时间 */
    onTick(): void;
    /** 重置计时器 */
    reset(): void;
}
