import { BaseComponent, ComponentManager } from "../core/component";
/** 困难模式组件 - 降低伤害输出 */
export declare class HardmodeComponent extends BaseComponent {
    /** 困难模式伤害修正值 */
    static readonly damageModifier = 0.6;
    /** 创建困难模式组件 */
    static create(): HardmodeComponent;
    private shouldRemoveDamageModifier;
    onAttach(manager: ComponentManager): boolean | void | Promise<boolean | void>;
    onDetach(manager: ComponentManager): void | Promise<void>;
}
/** 居合模式组件 - 增加伤害输出 */
export declare class RaidomodComponent extends BaseComponent {
    /** 居合模式伤害修正值 */
    static readonly damageModifier = 2;
    /** 创建居合模式组件 */
    static create(): RaidomodComponent;
    private shouldRemoveDamageModifier;
    private timer;
    private stage;
    onAttach(manager: ComponentManager): Promise<void>;
    onDetach(manager: ComponentManager): void | Promise<void>;
}
