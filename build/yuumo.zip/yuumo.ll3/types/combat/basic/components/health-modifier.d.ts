import { ComponentManager } from "../core/component";
import { Optional } from '@utils/optional';
declare const HealthModifier_base: import("../core/component").RequiredComponentCtor;
/** 生命值修正组件 - 随时间调整生命值 */
export declare class HealthModifier extends HealthModifier_base {
    readonly delta: number;
    readonly duration: number;
    private scheduler;
    private timer;
    private deltaTick;
    private atom;
    remain: number;
    constructor(delta: number, duration: number);
    /** 每tick更新生命值 */
    onTick(manager: ComponentManager, pl: Optional<Player>): void;
    /** 创建生命值修正组件 */
    static create({ delta, duration }: {
        delta: number;
        duration: number;
    }): HealthModifier;
}
export {};
