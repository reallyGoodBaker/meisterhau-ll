import { BaseComponent } from "../core/component";
/** 伤害修正组件 - 调整伤害值 */
export declare class DamageModifier extends BaseComponent {
    #private;
    /** 默认伤害修正值 */
    static defaultModifier: number;
    /** 默认伤害修正选项 */
    static defaultModifierOpt: DamageModifier;
    /** 创建伤害修正组件 */
    static create({ modifier }: {
        modifier: number;
    }): DamageModifier;
    /** 获取伤害修正值 */
    get modifier(): number;
    constructor(modifier?: number);
}
