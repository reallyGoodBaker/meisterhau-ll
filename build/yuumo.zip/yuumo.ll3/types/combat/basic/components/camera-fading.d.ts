import { BaseComponent, Component, ComponentManager } from '../core/component';
/** 过渡信息接口 */
interface TransInfo {
    /** 过渡曲线类型 */
    curve?: 'linear';
    /** 起始状态 [x, y, z, yaw, pitch] */
    from?: number[];
    /** 目标状态 [x, y, z, yaw, pitch] */
    to: number[];
    /** 过渡持续时间（tick数） */
    duration: number;
}
/** 过渡参数类型 */
type TransParams = [
    string,
    number[],
    number[],
    number
];
/** 相机淡入淡出组件 - 处理相机过渡效果 */
export declare class CameraFading extends BaseComponent {
    private config;
    /** 开始tick数 */
    private tickOffset;
    /** 是否已完成过渡 */
    private finished;
    /** 最终过渡参数 */
    readonly last: TransParams;
    /**
     * 构造函数
     * @param config 过渡配置数组
     */
    constructor(config?: TransInfo[]);
    /** 创建相机淡入淡出组件 */
    static create({ config }: {
        config: TransInfo[];
    }): Component;
    /** 获取从开始到现在的tick数 */
    dt(): number;
    /** 组件附加时记录开始时间 */
    onAttach(): boolean | void | Promise<boolean | void>;
    /** 复制数组内容 */
    copy(from: number[], to: number[]): void;
    /** 获取当前过渡信息 */
    getTransInfo(): TransParams;
    /** 每tick更新相机过渡效果 */
    onTick(manager: ComponentManager): void;
    /** 线性偏移计算 */
    offsetLinear(from: number[], to: number[], progress: number, target: number[], rotation: number[]): void;
    /** 根据攻击方向创建淡入淡出效果 */
    static fadeFromAttackDirection(abuser: Player | Entity, damageOpt: DamageOption): void;
}
export {};
