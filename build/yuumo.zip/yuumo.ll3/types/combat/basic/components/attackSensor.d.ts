import { Delegate } from "@utils/events";
import { CustomComponent } from "../core/component";
import { IncomingAttack } from "../default";
import { Actor } from "@utils/actor";
/** 攻击传感器组件 - 检测来袭攻击 */
export declare class AttackSensor extends CustomComponent {
    readonly onlySelf: boolean;
    readonly onlyTeammates: boolean;
    readonly range: number;
    constructor(onlySelf?: boolean, onlyTeammates?: boolean, range?: number);
    /** 当有攻击来袭时触发的事件委托 */
    readonly onWillAttack: Delegate<[IncomingAttack, Actor]>;
}
