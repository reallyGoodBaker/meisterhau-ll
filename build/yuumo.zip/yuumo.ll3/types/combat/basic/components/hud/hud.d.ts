import { BaseComponent, ComponentManager } from '../../core/component';
import { Optional } from "@utils/optional";
/** HUD组件参数接口 */
export interface HudComponentParams {
    /** HUD内容 */
    content?: string;
    /**
     * HUD类型
     * @link https://lse.liteldev.com/zh/apis/GameAPI/Player/#_6
     */
    type?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
    /** 淡入时间 */
    fadeIn?: number;
    /** 停留时间 */
    stay?: number;
    /** 淡出时间 */
    fadeOut?: number;
}
/** HUD组件 - 显示屏幕提示信息 */
export declare class HudComponent extends BaseComponent {
    content: string;
    type: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
    fadeIn: number;
    fadeOut: number;
    stay: number;
    /** HUD符号定义 */
    static symbols: {
        sword: string;
        bodyTech: string;
        trace: string;
    };
    static id: number;
    /** 创建HUD组件 */
    static create({ content, type, fadeIn, fadeOut, stay }?: HudComponentParams): HudComponent;
    readonly id: number;
    constructor(content?: string, type?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8, fadeIn?: number, fadeOut?: number, stay?: number);
    /** 每tick渲染HUD */
    onTick(manager: ComponentManager, pl: Optional<Player>): void;
    /** 渲染HUD到玩家屏幕 */
    renderHud(pl: Optional<Player>): void;
}
