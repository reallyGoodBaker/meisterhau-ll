import { CustomComponent } from "@combat/basic/core/component";
import { Actor } from "@utils/actor";
/** 伤害显示组件 - 显示伤害信息 */
export declare class HurtDisplay extends CustomComponent {
    /** 通知伤害事件 */
    static notifyHurt(instigator: Actor, victim: Actor, damageOpt: Required<DamageOption>): void;
    /** 处理受到伤害事件 */
    onHurt(instigator: Actor, victim: Actor, damageOpt: Required<DamageOption>): void;
    /** 处理造成伤害事件 */
    onDamage(instigator: Actor, victim: Actor, damageOpt: Required<DamageOption>): void;
}
