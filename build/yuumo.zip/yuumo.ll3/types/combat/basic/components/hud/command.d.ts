export declare function registerHudCommands(): void;
