import { Optional } from "@utils/optional";
import { ComponentManager } from "@core/component";
import { HudComponent, HudComponentParams } from "./hud";
/** 状态HUD组件 - 显示目标状态信息 */
export declare class StatusHud extends HudComponent {
    constructor(content?: string, type?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8, fadeIn?: number, fadeOut?: number, stay?: number);
    /** 创建状态HUD组件 */
    static create({ content, type, fadeIn, fadeOut, stay }?: HudComponentParams): StatusHud;
    private targetLock;
    private targetStamina;
    private stamina;
    /** 组件附加时初始化 */
    onAttach(manager: ComponentManager): void;
    /** 渲染状态信息 */
    renderStatus(): void;
    /** 整数进度显示 */
    private intProgress;
    /** 每tick更新状态HUD */
    onTick(manager: ComponentManager, pl: Optional<Player>): void;
}
