import { Team } from './team';
/** 比赛规则枚举 */
export declare enum MatchRules {
    /** 三局两胜制 */
    BestOf = 0,
    /** 固定回合制 */
    FixedRounds = 1
}
/** 比赛管理类 */
export declare class Match {
    readonly team1: Team;
    readonly team2: Team;
    readonly rule: MatchRules;
    readonly rounds: number;
    readonly wins: [number, number];
    currentRound: number;
    /** 所有比赛映射表 */
    static readonly matches: Map<Team, Match>;
    constructor(team1: Team, team2: Team, rule?: MatchRules, rounds?: number, wins?: [number, number], currentRound?: number);
    /** 查找队伍的比赛 */
    static findMatch(team: Team): Match | undefined;
    /** 销毁比赛 */
    destroy(): void;
    /** 获取领先分数 */
    lead(): number;
    /** 检查比赛是否结束 */
    finished(): boolean;
    /** 队伍获胜 */
    win(team: Team): void;
    /** 队伍失败 */
    lose(team: Team): void;
    /** 获取比赛结果 */
    result(): Team[];
}
