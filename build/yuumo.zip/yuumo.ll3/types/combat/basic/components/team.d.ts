import { BaseComponent } from '@core/component';
/** 队伍组件 - 管理玩家队伍 */
export declare class Team extends BaseComponent {
    /** 队伍名称 */
    name: string;
    /** 队伍玩家映射表 */
    static readonly players: Map<Team, Set<Player>>;
    constructor(
    /** 队伍名称 */
    name?: string);
    /** 创建队伍组件 */
    static create({ name }: {
        name: string;
    }): Team;
    /** 组件附加时添加玩家到队伍 */
    onAttach(): boolean | void | Promise<boolean | void>;
    /** 组件分离时从队伍移除玩家 */
    onDetach(): void | Promise<void>;
    /** 获取队伍成员 */
    getTeamMembers(): Set<Player>;
}
