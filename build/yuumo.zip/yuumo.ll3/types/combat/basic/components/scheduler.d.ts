import { BaseComponent } from "../core/component";
/** 调度器组件 - 按周期执行任务 */
export declare class Scheduler extends BaseComponent {
    /** 调度周期 */
    period: number;
    private offset;
    /** 是否更新标志 */
    update: boolean;
    constructor(
    /** 调度周期 */
    period?: number);
    /** 组件附加时初始化 */
    onAttach(): boolean | void | Promise<boolean | void>;
    /** 每tick检查是否需要更新 */
    onTick(): void;
}
