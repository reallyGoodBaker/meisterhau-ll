import { ComponentManager, CustomComponent } from "@combat/basic/core/component";
import { Optional } from "@utils/optional";
/** 技巧组件 - 管理战斗动作和技能 */
export declare class TrickComponent extends CustomComponent {
    /** 所有注册的技巧模块 */
    static readonly tricks: Map<string, TrickModule>;
    /** 当前动作名称 */
    moveName: string;
    /** 当前动作 */
    move: Move | ((name: string) => Move) | ((name: string) => boolean) | {
        parried: {
            left: string;
            vertical: string;
            right: string;
            middle: string;
        };
        hit: {
            left: string;
            right: string;
            vertical: string;
            middle: string;
        };
        parry: {
            left: string;
            vertical: string;
            right: string;
            middle: string;
        };
        knockdown: string;
        blocked: {
            left: string;
            vertical: string;
            right: string;
            middle: string;
        };
        block: {
            left: string;
            vertical: string;
            right: string;
            middle: string;
        };
        execution: {
            cutHead: string;
        };
        executionNoGore: {
            cutHead: string;
        };
    } | {
        parry: string;
        blocked: string;
        block: string;
    } | (<T extends import("../../default").DefaultMoves>(init: import("../../default").StateKey<T>) => void) | (<T extends import("../../default").DefaultMoves>(state: import("../../default").StateKey<T>, obj: any) => void) | (<T extends import("../../default").DefaultMoves>(state: import("../../default").StateKey<T>, transitionName: import("../../default").StateKey<T>, transition: TransitionTypeOption) => void);
    /** 动作已持续时间 */
    duration: number;
    /** 绑定的技巧模块 */
    trick: TrickModule;
    /** 加载技巧模块 */
    loadTrick(sid: string): void;
    /** 每tick更新技巧状态 */
    onTick(manager: ComponentManager, pl: Optional<Player>): void;
}
