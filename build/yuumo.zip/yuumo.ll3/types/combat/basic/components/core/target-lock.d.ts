import { Actor } from "@utils/actor";
import { BaseComponent } from "../../core/component";
import { Optional } from "@utils/optional";
import { Delegate } from "@utils/events";
/** 目标锁定组件 - 管理战斗中的目标锁定 */
export declare class TargetLock extends BaseComponent {
    /** 源角色 */
    source: Optional<Actor>;
    /** 目标角色 */
    target: Optional<Actor>;
    /** 源是否为玩家 */
    sourceIsPlayer: boolean;
    /** 目标是否为玩家 */
    targetIsPlayer: boolean;
    /** 目标是否为AI */
    targetIsAI: boolean;
    /** 目标是否为角色 */
    get targetIsActor(): boolean;
    constructor(
    /** 源角色 */
    source?: Optional<Actor>, 
    /** 目标角色 */
    target?: Optional<Actor>);
    /** 重置属性 */
    resetAttrs(): void;
    /** 组件附加时禁用跳跃和潜行 */
    onAttach(): void;
    /** 选择目标 */
    selectTarget(target: Actor): void;
    /** 失去锁定事件 */
    readonly onLoseLock: Delegate<[]>;
    /** 组件分离时恢复跳跃和潜行 */
    onDetach(): void;
}
