import { BaseComponent } from "../../core/component";
/** 输入类型定义 */
export declare enum InputTypes {
    Jump = 0,
    Sneak = 1,
    Sprint = 2,
    Attack = 3,
    Use = 4,
    Feint = 5
}
/** 输入组件 - 管理玩家输入控制 */
export declare class InputComponent extends BaseComponent {
    #private;
    /** 允许的输入类型 */
    allowedInputs: boolean[];
    /** 获取预输入 */
    get preInput(): null | InputTypes;
    /** 设置预输入 */
    set preInput(v: InputTypes);
}
