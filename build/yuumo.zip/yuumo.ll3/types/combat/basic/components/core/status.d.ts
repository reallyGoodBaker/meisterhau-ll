import { CustomComponent } from "../../core/component";
/** 状态组件 - 管理角色的战斗状态 */
export declare class StatusComponent extends CustomComponent {
    /** 是否可被击退 */
    repulsible: boolean;
    /** 玩家的硬直 */
    stiffness: number;
    /** 是否受到冲击 - 受到冲击的对象在碰到墙体时会造成短暂眩晕 */
    shocked: boolean;
    /** 是否霸体状态 */
    hegemony: boolean;
    /** 处于防御状态 */
    isBlocking: boolean;
    /** 处于招架等待状态 */
    isWaitingParry: boolean;
    /** 处于偏斜等待状态 */
    isWaitingDeflection: boolean;
    /** 处于闪避状态 */
    isDodging: boolean;
    /** 禁用血腥效果 */
    noGore: boolean;
}
