import { CustomComponent, ComponentManager } from "../../core/component";
import { Optional } from "@utils/optional";
import { Timer } from "../timer";
/** 体力组件 - 管理角色的体力系统 */
export declare class Stamina extends CustomComponent {
    /** 内部体力值 */
    $stamina: number;
    /** 最大体力值 */
    maxStamina: number;
    /** 每tick恢复量 */
    restorePerTick: number;
    /** 恢复冷却时间 */
    restoreCooldown: number;
    /** 冷却计时器 */
    cooldown: Optional<Timer>;
    /** 上一帧体力值 */
    prevStamina: number;
    /** 当前体力值 */
    get stamina(): number;
    /** 设置体力值（自动限制范围） */
    set stamina(v: number);
    constructor(
    /** 内部体力值 */
    $stamina?: number, 
    /** 最大体力值 */
    maxStamina?: number, 
    /** 每tick恢复量 */
    restorePerTick?: number, 
    /** 恢复冷却时间 */
    restoreCooldown?: number);
    /** 重置恢复冷却 */
    resetRestore(manager: ComponentManager): Promise<void>;
    /** 设置冷却时间 */
    setCooldown(cooldown: number): void;
    /** 每tick更新体力状态 */
    onTick(manager: ComponentManager): void;
}
