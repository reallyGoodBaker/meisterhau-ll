import { CustomComponent } from "@combat/basic/core/component";
import { Delegate } from "@utils/events";
import { Actor } from "@utils/actor";
/** AI视觉配置接口 */
export interface AiVisionConfig {
    /** 视野角度（弧度） */
    fov: number;
    /** 视野范围 */
    range: number;
    /** 检测间隔（tick数） */
    interval: number;
}
/** AI视觉组件 - 管理AI的视野检测功能 */
export declare class AiVision extends CustomComponent {
    #private;
    readonly config: AiVisionConfig;
    /**
     * 获取视野范围内的角色
     * @param config 视觉配置
     * @param actor 源角色
     * @returns 视野范围内的角色数组
     */
    static getActorsInSight(config: AiVisionConfig, actor: Actor): Actor[];
    /**
     * 构造函数
     * @param config AI视觉配置
     */
    constructor(config: AiVisionConfig);
    /** 当角色进入视野时触发的事件 */
    readonly onSeen: Delegate<[Actor]>;
    /** 当角色离开视野时触发的事件 */
    readonly onUnseen: Delegate<[Actor]>;
    /** 当前视野中可见的角色集合 */
    readonly seenActors: Set<Actor>;
    /** 每tick更新视野检测 */
    onTick(): void;
}
