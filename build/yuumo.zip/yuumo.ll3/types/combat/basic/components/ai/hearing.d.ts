import { CustomComponent } from "@combat/basic/core/component";
import { Actor } from "@utils/actor";
import { Delegate } from "@utils/events";
import { Optional } from "@utils/optional";
/** AI听觉配置接口 */
export interface AiHearingConfig {
    /** 监听的音频通道列表 */
    channels: string[];
    /**
     * 最低音量，低于该音量不触发
     */
    minVolumn?: number;
    /**
     * 最高音量，高于该音量不触发
     */
    maxVolumn?: number;
}
/** 音频源接口 */
export interface ISoundSource {
    /** 音频通道 */
    channel: string;
    /** 音频位置 */
    pos: IntPos | FloatPos;
    /** 音频源角色 */
    sourceActor: Optional<Actor>;
    /** 音量大小 */
    volumn: number;
}
/** AI听觉组件 - 管理AI的听觉检测功能 */
export declare class AiHearing extends CustomComponent {
    readonly conf: AiHearingConfig;
    /** 音频源映射表，按角色存储音频源 */
    static readonly aiHearingChannels: Map<Optional<Actor>, ISoundSource[]>;
    /**
     * 添加音频源
     * @param soundSource 音频源信息
     */
    static addSoundSource(soundSource: ISoundSource): void;
    /**
     * 尝试通知听觉组件
     * @param source 音频源信息
     */
    private static _tryNotifyHearing;
    /** 已听到的角色集合 */
    readonly heardActors: Set<Actor>;
    /**
     * 构造函数
     * @param conf AI听觉配置
     */
    constructor(conf: AiHearingConfig);
    /** 当听到音频时触发的事件 */
    readonly onHeard: Delegate<[ISoundSource]>;
}
