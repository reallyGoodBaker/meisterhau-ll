import { CustomComponent } from "../core/component";
/** Tick组件 - 全局游戏tick计数器 */
export declare class Tick extends CustomComponent {
    /** 当前游戏tick数 */
    static tick: number;
}
