import { BaseComponent } from "@combat/basic/core/component";
import { Actor } from "@utils/actor";
/** 获取近似攻击方向 */
export declare function getApproximatelyDir(direction: AttackDirection): "right" | "left";
/** 状态键类型 */
export type StateKey<T> = ObjKeyType<T, Move>;
/** 来袭攻击组件 */
export declare class IncomingAttack extends BaseComponent {
    damage: number;
    instigator: Actor;
    direction: AttackDirection;
    permeable: boolean;
    parryable: boolean;
    powerful: boolean;
    trace: boolean;
    cancel: boolean;
    constructor(damage: number, instigator: Actor, direction?: AttackDirection, permeable?: boolean, parryable?: boolean, powerful?: boolean, trace?: boolean);
    /** 获取近似攻击方向 */
    approximateAttackDirection(): "right" | "left";
    /** 添加此组件时，通知 AttackSensor */
    onAttach(): void;
}
/** 根据朝向设置速度 */
export declare function setVelocityByOrientation(pl: Player, ctx: MovementContext, max: number, offset?: number): void;
/** 默认动作集合 */
export declare class DefaultMoves implements Moves {
    /** 获取指定名称的动作 */
    getMove(name: string): Move;
    /** 检查是否存在指定名称的动作 */
    hasMove(name: string): boolean;
    animations: {
        parried: {
            /**
             * left and vertical
             */
            left: string;
            vertical: string;
            /**
             * right and stab
             */
            right: string;
            middle: string;
        };
        hit: {
            left: string;
            right: string;
            vertical: string;
            middle: string;
        };
        parry: {
            /**
             * left and vertical
             */
            left: string;
            vertical: string;
            /**
             * right and stab
             */
            right: string;
            middle: string;
        };
        knockdown: string;
        blocked: {
            /**
             * left and vertical
             */
            left: string;
            vertical: string;
            /**
             * right and stab
             */
            right: string;
            middle: string;
        };
        block: {
            /**
             * left and vertical
             */
            left: string;
            vertical: string;
            /**
             * right and stab
             */
            right: string;
            middle: string;
        };
        execution: {
            cutHead: string;
        };
        executionNoGore: {
            cutHead: string;
        };
    };
    sounds: {
        parry: string;
        blocked: string;
        block: string;
    };
    blocked: Move;
    block: Move;
    hurt: Move;
    execution: Move;
    hitWall: Move;
    parried: Move;
    parriedLeft: Move;
    parriedRight: Move;
    parry: Move;
    knockdown: Move;
    /** 设置状态转换 */
    setup<T extends DefaultMoves>(init: StateKey<T>): void;
    /** 混合状态属性 */
    mixin<T extends DefaultMoves>(state: StateKey<T>, obj: any): void;
    /** 设置状态转换 */
    setTransition<T extends DefaultMoves>(state: StateKey<T>, transitionName: StateKey<T>, transition: TransitionTypeOption): void;
}
/** 默认技巧模块 */
export declare class DefaultTrickModule implements TrickModule {
    sid: string;
    entry: string;
    bind: string | string[];
    moves: DefaultMoves;
    constructor(sid: string, entry: string, bind: string | string[], moves: DefaultMoves);
}
