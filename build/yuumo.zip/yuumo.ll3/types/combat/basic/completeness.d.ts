/** 检查技巧模块的完整性 */
export declare function checkCompleteness(mod: TrickModule): string | false;
