import { Status } from './status';
import { Actor } from '@utils/actor';
/** 事件发射器 */
export declare const emitter: import("../../../events").EventEmitter;
/** 初始化战斗组件 */
export declare function initCombatComponent(pl: Actor, bind: TrickModule, status: Status): void;
/** 状态转换 - 处理战斗状态转换逻辑 */
export declare function transition(pl: Actor, bind: TrickModule, status: Status, eventName: string, prevent: () => void, args: any[]): void;
/** 监听所有Minecraft事件 - 设置战斗系统的事件监听器 */
export declare function listenAllMcEvents(collection: TrickModule[]): void;
