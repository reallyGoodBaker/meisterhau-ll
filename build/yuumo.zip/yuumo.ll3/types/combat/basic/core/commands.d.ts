/**
 * 注册组件管理命令和实用工具命令
 * 包括组件添加、移除、列表、检查和更新功能
 * 以及武器给予等实用工具
 */
export declare function registerCommand(): void;
