import { DefaultTrickModule } from "@combat/basic/default";
declare class OrnateTwoHander extends DefaultTrickModule {
    constructor();
}
export declare const tricks: OrnateTwoHander;
export {};
