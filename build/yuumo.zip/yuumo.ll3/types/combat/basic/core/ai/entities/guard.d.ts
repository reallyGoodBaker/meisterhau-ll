import { MeisterhauAI } from '../core';
import { EasyAISensing } from '../easyAiSensing';
import { AiActions } from '../aiActions';
/**
 * 守卫AI类 - 实现守卫角色的AI行为
 * 包含多种策略：默认策略、疯狂策略、左连击策略
 */
export declare class Guard extends MeisterhauAI {
    target: Entity | null;
    readonly actions: AiActions;
    readonly sensing: EasyAISensing;
    /**
     * AI启动时初始化战斗组件
     */
    onStart(): Promise<void>;
    /**
     * 获取指定策略的状态机
     * @param strategy 策略名称
     * @returns 策略状态机生成器
     */
    getStrategy(strategy: string): AsyncGenerator<any, void, unknown> | undefined;
    /**
     * 尝试获取目标
     * @returns 是否成功获取目标
     */
    tryAcquireTarget(): Promise<boolean | undefined>;
    /**
     * 尝试释放目标（当目标离开范围时）
     */
    tryReleaseTarget(): Promise<void>;
    /**
     * 获取疯狂策略 - 随机执行攻击、使用物品、潜行动作
     * @returns 疯狂策略状态机生成器
     */
    getCrazyStrategy(): AsyncGenerator<any, void, unknown>;
    /**
     * 获取默认策略 - 根据玩家行为智能响应
     * 包含闪避惩罚、攻击响应、格挡破防等逻辑
     * @returns 默认策略状态机生成器
     */
    getDefaultStrategy(): AsyncGenerator<any, void, unknown>;
    /**
     * 获取左连击策略 - 简单的两连击组合
     * @returns 左连击策略状态机生成器
     */
    getLeftComboStrategy(): AsyncGenerator<any, void, unknown>;
}
