import { MeisterhauAI } from "../core";
import { AiActions } from "../aiActions";
import { EasyAISensing } from "../easyAiSensing";
import { IncomingAttack } from "@combat/basic/default";
/**
 * 忍野忍AI类 - 实现忍野忍角色的AI行为
 * 包含温和策略和守卫策略
 */
export declare class Shinobu extends MeisterhauAI {
    readonly actions: AiActions;
    readonly sensing: EasyAISensing;
    /**
     * 获取指定策略的状态机
     * @param strategy 策略名称
     * @returns 策略状态机生成器
     */
    getStrategy(strategy: string): any;
    /**
     * 处理AI选择/放弃目标的逻辑
     * 自动寻找目标并在目标离开范围时放弃
     */
    tryAcquireOrReleaseTarget(): Promise<void>;
    /**
     * 连招1 - 三连击组合
     * 包含攻击-攻击-攻击的连段，可被中断
     */
    combo1: () => Promise<void>;
    /**
     * 连招2 - 物品使用+攻击组合
     * 使用物品后接攻击，可被中断
     */
    combo2: () => Promise<void>;
    /**
     * 被攻击时的响应处理
     * @param incomingAttack 受到的攻击信息
     */
    onAttack(incomingAttack: IncomingAttack): Promise<void>;
    /**
     * 温和策略 - 根据目标距离和状态智能选择连招
     * 近距离优先使用连招2，中距离优先使用连招1
     * @returns 温和策略状态机生成器
     */
    mildStrategy(): AsyncGenerator<import("../core").MeisterhauAITask, void, unknown>;
    /**
     * 守卫策略 - 仅保持目标锁定，不主动攻击
     * 用于防御性行为
     * @returns 守卫策略状态机生成器
     */
    guardStrategy(): AsyncGenerator<never, void, unknown>;
}
