import { Status } from '@core/status';
import { Component, CustomComponent } from '../component';
import { Optional } from '@utils/optional';
import { Actor } from '@utils/actor';
/** AI任务接口 */
export interface MeisterhauAITask {
    (ai: MeisterhauAI): Promise<void>;
    (ai: MeisterhauAI): void;
    (): Promise<void>;
    (): void;
}
/** 简单中止控制器 */
export declare class SimpleAbortController {
    private _aborted;
    private _listeners;
    /** 获取中止信号 */
    get signal(): {
        aborted: boolean;
        addEventListener: (event: string, listener: () => void) => void;
        removeEventListener: (event: string, listener: () => void) => void;
    };
    /** 中止所有任务 */
    abort(): void;
}
/** Meisterhau AI 基类 - 管理AI行为和状态机 */
export declare abstract class MeisterhauAI {
    readonly actor: Optional<Actor>;
    strategy: string;
    readonly abortController: SimpleAbortController;
    readonly status: Status;
    constructor(actor: Optional<Actor>, strategy?: string);
    abstract getStrategy(strategy: string): AsyncGenerator<MeisterhauAITask, void, unknown> | undefined;
    private _fsm?;
    private _waitExecuting;
    /**
     * 检查是否有正在执行的任务
     * @returns 是否有正在执行的任务
     */
    hasAnyExecutingTasks(): boolean;
    /**
     * 检查是否有待执行的任务
     * @returns 是否有待执行的任务
     */
    hasAnyTasks(): boolean;
    /**
     * 提交执行完成，通知所有等待中的任务
     */
    private submitExecuting;
    /**
     * 等待所有执行中的任务完成
     * @returns Promise，在所有任务完成时解析
     */
    waitExecutingTasks(): Promise<void>;
    /**
     * 等待指定毫秒数，可被中止
     * @param ms 等待的毫秒数，默认为0
     * @returns Promise，在等待时间结束或被中止时解析
     */
    wait(ms?: number): Promise<void>;
    private _tasks;
    /**
     * 当 force 为 true 时，无论当前是否已有任务正在执行，都将执行该任务
     * 否则，只有当当前没有任务正在执行时，才会执行该任务
     * @param task
     * @param force
     */
    /**
     * 执行AI任务
     * @param task 要执行的AI任务
     * @param force 是否强制执行，忽略当前是否有任务正在执行
     */
    executeTask(task: MeisterhauAITask, force?: boolean): void;
    private _executeTasks;
    /** AI tick更新方法 */
    tick(): Promise<void>;
    /** AI启动时调用 */
    onStart(): void;
    /** AI更新时调用 */
    onUpdate(breakVal: (val?: any) => void): void;
    /** AI停止时调用 */
    onStop(breakVal?: any): void;
    private aiTicker?;
    /** 创建AI循环，在每次tick时执行表达式 */
    loop<T = any>(expr: (value: (val?: T) => void) => T | Promise<T>): T | Promise<T>;
    /** 设置AI策略 */
    setStrategy(strategy: string): AsyncGenerator<MeisterhauAITask, void, unknown> | undefined;
    _start(cleanStart?: boolean): Promise<void>;
    /** 启动AI */
    start(): void;
    /** 停止AI */
    stop(returnVal?: any): void;
    /** 等待指定tick数 */
    waitTick(ticks?: number): Promise<void>;
    /** 获取AI是否已停止 */
    get stopped(): boolean;
    /** 重启AI，可选择新策略 */
    restart(strategy?: string): Promise<boolean>;
    /** 根据权重随机选择动作 */
    randomActions(...conf: [number, MeisterhauAITask][]): MeisterhauAITask;
}
/** AI注册信息接口 */
export interface AiRegistration {
    type: string;
    ai: ConstructorOf<MeisterhauAI>;
    tricks: TrickModule;
    components?: Component[];
    setup?(ai: MeisterhauAI, entity: Entity): void;
}
/** AI管理器命名空间 */
export declare namespace ai {
    /** 注册AI类型 */
    function register(registration: AiRegistration): void;
    /** 获取AI注册信息 */
    function getRegistration(type: string): AiRegistration;
    /** 获取实体的AI实例 */
    function getAI(en: Entity): MeisterhauAI | undefined;
    /** 检查实体是否已注册AI */
    function isRegistered(en: Entity): boolean;
}
/** AI标识组件 */
export declare class IsAI extends CustomComponent {
}
export declare function listenEntitiyWithAi(): Promise<void>;
