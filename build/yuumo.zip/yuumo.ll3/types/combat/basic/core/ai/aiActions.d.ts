import { InputSimulator } from "../inputSimulator";
import { Actor } from "@utils/actor";
/**
 * AI动作类 - 扩展输入模拟器，提供AI特定的动作功能
 * 包括目标设置、视线追踪、事件触发等
 */
export declare class AiActions extends InputSimulator {
    /**
     * 设置AI的目标
     * @param target 目标角色
     */
    setTarget(target: Actor): void;
    /**
     * 移除AI的目标
     */
    removeTarget(): void;
    /**
     * 看向最近的实体
     * @param radius 搜索半径，默认为10
     * @param family 实体类型数组，默认为['mob']
     */
    lookAtNearest(radius?: number, family?: string[]): void;
    /**
     * 将前方实体设置为目标
     * @param length 视线距离，默认为8
     * @returns 是否成功设置目标
     */
    setForwardActorAsTarget(length?: number): boolean | undefined;
    /**
     * 触发预定义的事件
     * @param event 事件名称
     */
    triggerDefinedEvent(event: string): void;
}
