import { MeisterhauAI } from "./core";
import { Optional } from "@utils/optional";
import { Status } from "../status";
import { AiHearing } from "@combat/basic/components/ai/hearing";
import { AiVision } from "@combat/basic/components/ai/vision";
import { Actor } from "@utils/actor";
/**
 * 简易AI感知类 - 提供AI目标感知和状态检测功能
 */
export declare class EasyAISensing {
    readonly ai: MeisterhauAI;
    /**
     * 构造函数
     * @param ai AI实例
     */
    constructor(ai: MeisterhauAI);
    /**
     * 获取组件管理器
     * @returns 组件管理器实例
     */
    get components(): import("../component").ComponentManager;
    /**
     * 检查是否有有效目标
     * @returns 是否有有效目标
     */
    hasTarget(): boolean;
    /**
     * 获取当前目标
     * @returns 目标角色的Optional对象
     */
    getTarget(): Optional<Actor>;
    /**
     * 检查目标是否在指定范围内
     * @param range 检测范围
     * @returns 目标是否在范围内
     */
    targetInRange(range: number): boolean;
    /**
     * 获取目标的状态
     * @returns 目标状态的Optional对象
     */
    targetStatus(): Optional<Status>;
    /**
     * 检查目标是否输入了指定类型的输入
     * @param inputTypes 输入类型数组
     * @returns 目标是否输入了指定类型
     */
    hasTargetInputed(...inputTypes: (keyof InputableTransitionMap)[]): boolean;
    /**
     * 检查是否能听到目标
     * @param hearingCtor 听觉组件构造函数，默认为AiHearing
     * @returns 是否能听到目标
     */
    canHearTarget(hearingCtor?: ConstructorOf<AiHearing>): boolean;
    /**
     * 检查是否能看见目标
     * @param visionCtor 视觉组件构造函数，默认为AiVision
     * @returns 是否能看见目标
     */
    canSeeTarget(visionCtor?: ConstructorOf<AiVision>): boolean;
    /**
     * 检查目标是否正在格挡
     * @returns 目标是否正在格挡
     */
    targetIsBlocking(): boolean;
    /**
     * 检查AI是否处于被中断状态
     * @param iterapted 中断状态数组，默认为['blocked', 'parried', 'hurt']
     * @returns AI是否处于被中断状态
     */
    actorIterapted(iterapted?: string[]): boolean;
}
