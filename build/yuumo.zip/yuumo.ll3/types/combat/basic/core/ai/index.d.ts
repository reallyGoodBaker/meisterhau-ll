import './entities';
export declare function setupAiCommands(): void;
