import { EventInputStream } from "../generic/event-stream";
export declare const em: import("../../../events").EventEmitter;
export declare const es: EventInputStream;
