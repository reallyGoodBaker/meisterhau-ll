import { Component, ComponentCtor } from "./component";
/** 可命令构造的组件构造函数类型 */
type CommandConstructableCtor = ComponentCtor & {
    create(...args: any[]): Component;
};
/** 根据组件ID获取组件构造函数 */
export declare const getComponentCtor: (id: string) => CommandConstructableCtor | undefined;
/** 根据组件构造函数获取组件ID */
export declare const getComponentId: (t: ComponentCtor) => string | undefined;
/** 公共组件装饰器 - 注册组件到公共注册表 */
export declare const PublicComponent: (name: string) => ClassDecorator;
/** 字段装饰器 - 定义组件的可变和只读字段 */
export declare const Fields: (muts: string[], lets?: string[]) => ClassDecorator;
/** 获取组件的字段条目 */
export declare function getFieldEntries(t: any): {
    muts: any[];
    lets: any[];
} | null;
export {};
