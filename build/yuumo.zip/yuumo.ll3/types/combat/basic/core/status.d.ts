import { Optional } from '@utils/optional';
import { ComponentManager } from './component';
export declare const defaultAcceptableInputs: string[];
export declare class Status {
    #private;
    private readonly uniqueId;
    /** 存储所有状态的映射表 */
    static readonly status: Map<string, Status>;
    /**
     * 根据唯一ID获取状态
     * @param uniqueId 实体的唯一ID
     * @returns 状态对象，如果不存在则返回undefined
     */
    static get(uniqueId: string): Status | undefined;
    /**
     * 获取实体的组件管理器
     * @param uniqueId 实体的唯一ID
     * @returns 包含组件管理器的Optional对象
     */
    static getComponentManager(uniqueId: string): Optional<ComponentManager>;
    /**
     * 获取或创建状态对象
     * @param uniqueId 实体的唯一ID
     * @returns 状态对象
     */
    static getOrCreate(uniqueId: string): Status;
    /** 全局状态实例 */
    static readonly global: Status | undefined;
    /**
     * 手上物品的type
     */
    hand: string;
    /**
     * moves中当前move的名称
     */
    status: string;
    /**
     * 动作已持续时间
     */
    duration: number;
    /**
     * 玩家预输入
     */
    preInput: string | null;
    /**
     * 是否可被击退
     */
    repulsible: boolean;
    /**
     * 玩家的精力(不是饱和度也不是生命值)
     */
    stamina: number;
    /**
     * 玩家的硬直
     */
    stiffness: number;
    /**
     * 是否受到冲击
     * 受到冲击的对象在碰到墙体时会造成短暂眩晕
     */
    shocked: boolean;
    /**
     * 是否霸体状态
     */
    hegemony: boolean;
    /**
     * 处于防御状态
     */
    isBlocking: boolean;
    /**
     * 处于招架等待状态
     */
    isWaitingParry: boolean;
    /**
     * 处于偏斜等待状态
     */
    isWaitingDeflection: boolean;
    /**
     * 处于闪避状态
     */
    isDodging: boolean;
    /**
     * 玩家是否处于无敌状态
     */
    isInvulnerable: boolean;
    /**
     * 玩家接受的事件输入
     */
    readonly acceptableInputs: Set<string>;
    static defaultCameraOffsets: number[];
    cameraOffsets: number[];
    /**
     * 组件管理器
     */
    readonly componentManager: ComponentManager;
    constructor(uniqueId: string);
    reset(): void;
    /**
     * 设置或检查输入是否可接受
     * @param name 输入名称
     * @param accept 是否接受该输入，可选（不提供时返回当前状态）
     * @returns 当不提供accept参数时返回该输入是否可接受
     */
    acceptableInput(name: string, accept?: boolean): boolean | undefined;
    /**
     * 启用指定的输入类型
     * @param inputs 要启用的输入类型数组
     */
    enableInputs(inputs: string[]): void;
    /**
     * 禁用指定的输入类型
     * @param inputs 要禁用的输入类型数组
     */
    disableInputs(inputs: string[]): void;
    /**
     * 设置预输入，500ms后自动清除
     * @param input 预输入类型
     */
    setPreInput(input: AcceptbleInputTypes): void;
}
