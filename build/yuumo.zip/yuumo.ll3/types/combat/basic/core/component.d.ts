import { Actor } from '@utils/actor';
import { Optional } from '@utils/optional';
/** 组件基础接口 */
export interface Component {
    /** 是否允许tick更新 */
    allowTick: boolean;
    /** tick更新方法 */
    onTick(manager: ComponentManager, en: Optional<Actor>): void;
    /** 分离组件 */
    detach(manager: ComponentManager): void;
    /** 获取组件管理器 */
    getManager(): ComponentManager;
    /** 获取所属演员 */
    getActor(): Optional<Actor>;
}
/** 基础组件接口 - 包含附加和分离生命周期 */
export interface BasicComponent extends Component {
    /** 组件附加时调用 */
    onAttach(manager: ComponentManager): boolean | void | Promise<boolean | void>;
    /** 组件分离时调用 */
    onDetach(manager: ComponentManager): void | Promise<void>;
}
/** 反射管理器符号 */
export declare const REFLECT_MANAGER: unique symbol;
/** 反射实体符号 */
export declare const REFLECT_ENTITY: unique symbol;
/** 自定义组件基类 */
export declare class CustomComponent implements Component {
    [REFLECT_MANAGER]?: ComponentManager;
    [REFLECT_ENTITY]: Optional<Actor>;
    allowTick: boolean;
    onTick(manager: ComponentManager, en: Optional<Actor>): void;
    detach(manager: ComponentManager): boolean;
    getManager(): ComponentManager;
    getActor(): Optional<Actor>;
}
/** 基础组件实现类 */
export declare class BaseComponent extends CustomComponent implements BasicComponent {
    onAttach(manager: ComponentManager): boolean | void | Promise<boolean | void>;
    onDetach(manager: ComponentManager): void | Promise<void>;
}
/** 组件构造函数接口 */
export interface ComponentCtor<T extends Component | BasicComponent = Component> {
    new (...args: any[]): T;
}
/** 组件管理器 - 管理组件的生命周期和更新 */
export declare class ComponentManager {
    #private;
    readonly owner: Optional<Actor>;
    constructor(owner: Optional<Actor>);
    static profilerEnable: boolean;
    static readonly global: ComponentManager;
    /**
     * 获取指定类型的组件
     * @param ctor 组件构造函数
     * @returns 包含组件的Optional对象
     */
    getComponent<T extends Component>(ctor: ComponentCtor<T>): Optional<T>;
    /**
     * 获取组件管理器的所有者
     * @returns 所有者实体
     */
    getOwner(): Actor | null;
    /**
     * 获取多个指定类型的组件
     * @param ctor 组件构造函数数组
     * @returns 组件数组，不存在的组件返回undefined
     */
    getComponents(...ctor: ComponentCtor[]): (Component | undefined)[];
    attachComponent(...component: Component[]): Optional<Component>[];
    getOrCreate<T extends Component>(ctor: ComponentCtor<T>, ...args: any[]): Optional<T>;
    detachComponent(ctor: ComponentCtor): boolean;
    clear(): void;
    getComponentKeys(): IterableIterator<ComponentCtor<Component>>;
    has(ctor: ComponentCtor): boolean;
    afterTick(fn: (en: Optional<Actor>) => void): void;
    beforeTick(fn: (en: Optional<Actor>) => void): void;
    handleTicks(en: Actor): void;
    update<T extends Component>(ctor: ComponentCtor<T>, fn: (component: T) => void): boolean;
    profiler(fn: Function, component?: Component, name?: string): any;
}
/** 必需组件参数类型 */
type RequireComponentsParam = ComponentCtor | [ComponentCtor, ...any[]];
/** 必需组件符号 */
export declare const REQUIRED_COMPONENTS: unique symbol;
/** 必需组件接口 */
export interface RequiredComponent extends BasicComponent {
    /** 获取必需组件 */
    getComponent<T extends Component>(ctor: ComponentCtor): T;
}
/** 必需组件构造函数类型 */
export type RequiredComponentCtor = ConstructorOf<RequiredComponent>;
/** 创建必需组件装饰器 */
export declare function RequireComponents(...params: RequireComponentsParam[]): RequiredComponentCtor;
export {};
