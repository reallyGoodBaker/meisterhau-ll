import { MeisterhauAI } from "./ai/core";
import { Optional } from "@utils/optional";
import { Actor } from "@utils/actor";
/**
 * 全局输入模拟器 - 用于模拟玩家输入事件
 */
declare class GlobalInputSimulator {
    /**
     * 模拟输入事件
     * @param input 输入事件类型
     * @param actor 目标角色
     * @param extraArgs 额外参数
     */
    simulate(input: keyof InputableTransitionMap, actor: Actor, ...extraArgs: any[]): void;
    /**
     * 模拟跳跃输入
     * @param actor 目标角色
     */
    jump(actor: Actor): void;
    /**
     * 模拟潜行输入
     * @param actor 目标角色
     * @param isSneaking 是否潜行，默认为true
     */
    sneak(actor: Actor, isSneaking?: boolean): void;
    /**
     * 模拟释放潜行输入
     * @param actor 目标角色
     * @param isSneaking 是否潜行，默认为false
     */
    releaseSneak(actor: Actor, isSneaking?: boolean): void;
    /**
     * 模拟使用物品输入
     * @param actor 目标角色
     * @param item 物品对象，可选
     */
    useItem(actor: Actor, item?: Item): void;
    /**
     * 模拟切换疾跑输入
     * @param actor 目标角色
     * @param isSprinting 是否疾跑，默认为true
     */
    changeSprinting(actor: Actor, isSprinting?: boolean): void;
    /**
     * 模拟攻击输入
     * @param actor 目标角色
     */
    attack(actor: Actor): void;
    /**
     * 模拟假动作输入
     * @param actor 目标角色
     */
    feint(actor: Actor): void;
    /**
     * 模拟闪避输入
     * @param actor 目标角色
     */
    dodge(actor: Actor): void;
}
export declare const inputSimulator: GlobalInputSimulator;
/**
 * AI输入模拟器 - 为AI角色提供输入模拟功能
 */
export declare class InputSimulator {
    protected ai: MeisterhauAI;
    readonly actor: Optional<Actor>;
    /**
     * 构造函数
     * @param ai AI实例
     */
    constructor(ai: MeisterhauAI);
    /**
     * 模拟跳跃输入
     * @param timeout 跳跃持续时间（毫秒），默认为300ms
     */
    jump(timeout?: number): Promise<void>;
    /**
     * 模拟潜行输入
     */
    sneak(): void;
    /**
     * 模拟释放潜行输入
     */
    releaseSneak(): void;
    /**
     * 模拟使用物品输入
     * @param item 物品对象，可选
     */
    useItem(item?: Item): void;
    /**
     * 模拟切换疾跑输入
     * @param isSprinting 是否疾跑，默认为true
     */
    changeSprinting(isSprinting?: boolean): void;
    /**
     * 模拟攻击输入
     */
    attack(): void;
    /**
     * 模拟假动作输入
     */
    feint(): void;
    /**
     * 模拟闪避输入
     */
    dodge(): void;
}
export {};
