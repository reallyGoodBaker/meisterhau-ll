/** 创建HUD进度条 */
export declare function hud(progress: number, size: number, style?: string[]): string;
