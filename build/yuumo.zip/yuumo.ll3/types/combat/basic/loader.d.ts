export default function loadAll(): Promise<void>;
