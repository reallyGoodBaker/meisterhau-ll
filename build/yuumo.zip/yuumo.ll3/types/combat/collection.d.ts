declare const _exports: typeof import("./tricks/empty-hand")[];
export = _exports;
