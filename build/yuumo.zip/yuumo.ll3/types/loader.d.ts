export declare class PackLoader {
    protected readonly levelName: string;
    protected readonly tmpDir: string;
    constructor();
    protected tryDecompress(packName: string): Promise<boolean>;
    protected tryLoadScriptFromTmp(packName: string): Promise<any>;
    private _getLevelName;
    protected load(packName: string): Promise<void>;
    private _symLinks;
    protected linkAssets(packName: string): Promise<void>;
    protected unlinkAssets(): Promise<void>;
    private _worldResBak?;
    private _worldBehBak?;
    protected updateLevelSettings(): Promise<void>;
    protected restoreLevelSettings(): Promise<void>;
    releasePacks(): Promise<void>;
    loadPacks(): Promise<void>;
}
