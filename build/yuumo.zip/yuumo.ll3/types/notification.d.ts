export class Notification {
    importance: number;
    type: number;
    title: string;
    preview: string;
    sound: string;
    /**@type {string}*/
    content: string;
    /**@private*/ private viewed;
    /**@private*/ private notified;
    /**@private*/ private timeStamp;
    /**@private*/ private expired;
    onerror: () => void;
    /**@private*/ private _buildMsgNotification;
    /**@private*/ private _buildActionNotification;
    /**@private*/ private _buildModalNotification;
    _buildMessage(): string | undefined;
    /**@private*/ private _notifyNormalMsg;
    /**@private*/ private _notifyImportantMsg;
    getListTilePreview(): string;
    displayFullContent(pl: any): any;
    expire(): void;
    notify(pl: any): void;
}
export namespace NotificationImportances {
    let NORMAL: number;
    let IMPORTANT: number;
}
export namespace NotificationTypes {
    let MESSAGE: number;
    let ACTION: number;
    let MODAL: number;
}
declare function regNotifComponent(): void;
export { regNotifComponent as setup };
