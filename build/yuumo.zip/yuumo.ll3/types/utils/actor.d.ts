import { Component } from "@combat/basic/core/component";
import { Optional } from "./optional";
/** 演员类型 - 可以是玩家或实体 */
export type Actor = Player | Entity;
/** 演员助手类 - 提供对演员（玩家/实体）的各种操作 */
export declare class ActorHelper {
    /**
     * 将演员转换为实体
     * @param actor - 演员对象
     * @returns
     */
    static toEntity(actor: Actor): Entity;
    /**
     * 将演员转换为玩家
     * @param actor - 演员对象
     * @returns
     */
    static toPlayer(actor: Actor): Player | undefined;
    /**
     * 根据信息获取玩家
     * @param info - 玩家信息（名称或标识符）
     * @returns
     */
    static getPlayer(info: string): Optional<Actor>;
    /**
     * 根据信息获取实体
     * @param info - 实体信息（标识符）
     * @returns
     */
    static getEntity(info: string | number): Optional<Actor>;
    /** 玩家标识符集合 */
    private static players;
    /**
     * 检查演员是否为玩家
     * @param actor - 演员对象
     * @returns
     */
    static isPlayer(actor: Actor): boolean;
    /**
     * 根据信息获取演员（优先尝试获取玩家）
     * @param info - 演员信息
     * @returns
     */
    static getActor(info: string | number): Optional<Actor>;
    /**
     * 获取演员的组件
     * @param actor - 演员对象
     * @param ctor - 组件构造函数
     * @returns
     */
    static getComponent<T extends Component>(actor: Actor, ctor: ConstructorOf<T>): Optional<T>;
    /**
     * 获取演员位置（Optional包装）
     * @param actor - 演员对象
     * @returns
     */
    static pos(actor: Actor): Optional<FloatPos>;
    /**
     * 获取演员位置（直接返回，如果不存在则返回零向量）
     * @param actor - 演员对象
     * @returns
     */
    static position(actor: Actor): FloatPos;
}
