/** 字符串参数类型映射 */
declare const stringParamTypeMap: {
    bool: ParamType;
    int: ParamType;
    float: ParamType;
    string: ParamType;
    entity: ParamType;
    actor: ParamType;
    player: ParamType;
    xyz: ParamType;
    pos: ParamType;
    vec: ParamType;
    text: ParamType;
    message: ParamType;
    json: ParamType;
    item: ParamType;
    block: ParamType;
    effect: ParamType;
    enum: ParamType;
    softEnum: ParamType;
    entities: ParamType;
    actor_type: ParamType;
    command: ParamType;
    selector: ParamType;
};
type TypeStr = keyof typeof stringParamTypeMap;
type CommandTypeStr = `?${TypeStr}` | TypeStr;
type CommandArr = {
    [key: string]: CommandTypeStr;
}[];
/** 命令处理器类型 */
type Handler<T = any> = (cmd: Command, origin: CommandOrigin, output: CommandOutput, result: T) => void;
/** 命令注册器 */
export declare class Registry {
    private _cmd;
    private _tokenListCollection;
    private _handlerCollection;
    constructor(cmd: Command);
    /** 获取指定长度的处理器集合 */
    private getCollection;
    /** 注册命令 */
    register(cmd: string, handler: Handler): this;
    /** 比较两个数组是否相同 */
    private sameArr;
    /** 设置命令回调 */
    private setCallback;
    private registeredArgs;
    static enumIndex: number;
    /** 创建命令参数 */
    private createArg;
    private _submitted;
    /** 提交命令注册 */
    submit(): void;
    /** 检查是否已提交 */
    isSubmitted(): boolean;
}
/** 命令权限枚举 */
export declare enum CommandPermission {
    Everyone = 0,
    OP = 1,
    Console = 2
}
/** 服务器启动状态检查 */
export declare const serverStarted: () => Promise<void>;
/** 配置处理器类型 */
export type ConfigHandler<T> = (args: T, origin: Player | Entity) => string | string[];
/** 创建命令 */
export declare function cmd(head: string, desc: string, perm?: 0 | 1 | 2): {
    setup: (executor: (register: <T = any>(cmd: string | CommandArr, handler: Handler<T>) => void, registry: Registry) => void | Promise<void>) => Promise<void>;
    getRegistry: () => Registry;
    configure: (executor: (register: <T = any>(cmd: string | CommandArr, handler: ConfigHandler<T>) => void, registry: Registry) => void | Promise<void>) => Promise<void>;
};
export {};
