export declare class NonNullMap<K, V> implements Map<K, V> {
    private readonly empty;
    constructor(empty: () => V);
    clear(): void;
    delete(key: K): boolean;
    forEach(callbackfn: (value: V, key: K, map: Map<K, V>) => void, thisArg?: any): void;
    get(key: K): V;
    set(key: K, value: V): this;
    has(key: K): boolean;
    get size(): number;
    entries(): IterableIterator<[K, V]>;
    keys(): IterableIterator<K>;
    values(): IterableIterator<V>;
    [Symbol.iterator](): IterableIterator<[K, V]>;
    get [Symbol.toStringTag](): string;
    private readonly map;
}
