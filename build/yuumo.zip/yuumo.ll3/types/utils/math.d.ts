/** 限制计算函数结果在指定范围内 */
export declare function constrictCalc(start: number, end: number, calcFn: () => number): number;
/** 将数值限制在最小值和最大值之间 */
export declare function minmax(min: number, max: number, val: number): number;
/** 生成指定范围内的随机数 */
export declare function randomRange(min?: number, max?: number, integer?: boolean): number;
/** 数值数组线性插值 */
export declare const lerpn: (from: number[], to: number[], progress: number) => any[];
/** 角度数组线性插值（处理360度循环） */
export declare const alerpn: (from: number[], to: number[], progress: number) => any[];
/** 三维向量接口 */
export interface Vector {
    x: number;
    y: number;
    z: number;
}
/** 向量工具类 */
export declare class VectorHelper {
    /** 创建零向量 */
    static zero(): Vector;
}
/** 旋转角度接口 */
export interface Rotation {
    yaw: number;
    pitch: number;
}
/** 将偏航角转换为二维向量 */
export declare function yawToVec2(yaw: number): {
    x: number;
    y: number;
};
