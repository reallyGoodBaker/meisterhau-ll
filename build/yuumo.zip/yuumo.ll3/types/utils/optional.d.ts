export declare class Optional<T = any> {
    private value;
    static none<T>(): Optional<T>;
    static some<T>(value: T | Optional<T> | null | undefined): Optional<T>;
    constructor(value: T);
    unwrap(): T;
    isEmpty(): boolean;
    orElse(other: T): T;
    use(fn: (v: T) => void, self?: any): boolean;
    match<R>(none: R | (() => R), some: (v: T) => R): R;
}
