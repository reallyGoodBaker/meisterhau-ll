import { Optional } from "@utils/optional";
export declare function getPlayer(info: string, init: (pl: Player) => void): Optional<Player>;
