export type Matcher<T> = T | ((item: T) => boolean);
export declare function testMatch<T>(item: T, matcher: Matcher<T>): boolean;
