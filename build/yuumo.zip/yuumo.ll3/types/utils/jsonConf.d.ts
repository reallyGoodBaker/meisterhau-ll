export declare class JsonConf<T extends Record<string, any>> {
    readonly filePath: string;
    constructor(filePath: string, defaultVal: T);
    private _cache;
    read(): any;
    write(data: any): void;
    update(): void;
    reload(): void;
    delete(key: string): void;
    get(key: keyof T): any;
    set(key: keyof T, value: any): void;
    has(key: string): boolean;
    clear(): void;
    remove(): void;
    exists(): boolean;
    init<T>(name: string, defaultVal: T): T;
}
