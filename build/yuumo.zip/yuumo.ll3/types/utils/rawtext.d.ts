export declare namespace r {
    function score(name: string, objective: string): {
        score: {
            name: string;
            objective: string;
        };
    };
    function translate(key: string): {
        translate: string;
    };
    const t: typeof translate;
    function selector(expr: string): {
        selector: string;
    };
}
export declare function rawtext(seqs: TemplateStringsArray, ...args: any[]): string;
