export declare const returnIf: (cond: boolean, value: any) => any;
export declare const interruptIf: (cond: boolean) => void;
export declare const returnExcept: (cond: boolean, value: any) => any;
export declare const interruptExcept: (cond: boolean) => void;
