export declare class Delegate<A extends any[] = []> {
    private _listener?;
    bind(listener: (...args: A) => void): void;
    unbind(): void;
    call(...args: A): void;
}
