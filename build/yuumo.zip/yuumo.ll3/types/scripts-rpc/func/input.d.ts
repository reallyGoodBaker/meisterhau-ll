import { EventEmitter } from '../../events';
export declare enum ButtonState {
    Pressed = "Pressed",
    Released = "Released"
}
export interface InputInfo {
    jump: boolean;
    sneak: boolean;
    x: number;
    y: number;
}
export declare function eventCenter(opt: any): EventEmitter;
export declare namespace input {
    function isPressing(pl: Player, button: 'jump' | 'sneak'): boolean;
    function performPress(id: string, button: 'jump' | 'sneak'): void;
    function performRelease(id: string, button: 'jump' | 'sneak'): void;
    function movementVector(pl: Player): {
        x: number;
        y: number;
    };
    function performMove(id: string, x: number, y: number): void;
    enum Direction {
        Forward = 1,
        Backward = 2,
        Left = 4,
        Right = 8
    }
    function moveDir(pl: Player): number;
    enum Orientation {
        None = 0,
        Forward = 1,
        Backward = 3,
        Left = 4,
        Right = 2
    }
    function approximateOrientation(pl: Player): 0 | Orientation.Forward | Orientation.Backward | Orientation.Left | Orientation.Right;
}
