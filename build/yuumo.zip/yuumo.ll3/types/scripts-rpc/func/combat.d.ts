import { Actor } from '@utils/actor';
export declare function damage(victim: Actor, damage: number, cause: any, abuser: Actor, projectile: Actor): Promise<any>;
export declare function _damageLL(victim: Actor, damage: number): void;
export declare function setRotation(en: Actor, pitch: number, yaw: number): Promise<any>;
