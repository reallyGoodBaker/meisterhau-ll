export function knockback(en: any, x: any, z: any, h: any, v: any): Promise<any>;
export function impulse(en: any, x: any, y: any, z: any): Promise<any>;
export function clearVelocity(en: any): Promise<any>;
export function applyKnockbackAtVelocityDirection(en: any, h: any, v: any): Promise<any>;
export function rotate(en: any, pitch: any, yaw: any): Promise<any>;
export function faceTo(src: any, t: any): Promise<any>;
