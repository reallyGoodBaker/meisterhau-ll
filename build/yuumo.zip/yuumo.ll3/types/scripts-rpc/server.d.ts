declare function setup(list: any, em: any): HttpServer;
export function setupNodeHttpServer(list: any, em: any): http.Server<typeof http.IncomingMessage, typeof http.ServerResponse>;
/**@type {Map<string, {jump: boolean, sneak: boolean, x: number, y: number}>} */
export const inputStates: Map<string, {
    jump: boolean;
    sneak: boolean;
    x: number;
    y: number;
}>;
import http = require("http");
export { setup as createServer };
