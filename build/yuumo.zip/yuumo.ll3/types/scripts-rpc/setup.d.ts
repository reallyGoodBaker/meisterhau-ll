export function setup(): void;
export function unload(): void;
export namespace remote {
    export { remoteCall as call };
    export { remoteFunction as expose };
}
declare function remoteCall(name: any, ...args: any[]): Promise<any>;
declare function remoteFunction(name: any, func: any): void;
export {};
