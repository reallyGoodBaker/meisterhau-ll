export declare function getNameByXuid(xuid: string): any;
export declare function propose(xuid: string, xuid2: string): any;
export declare function divorce(xuid: string, xuid2: string): any;
export interface FamilyQuery {
    filter?: (pl: Player) => boolean;
    sort?: (a: Player, b: Player) => number;
    name?: string;
}
export interface FamilyMember {
    xuid: string;
    name: string;
    agent: boolean;
}
export declare function queryFamilies(xuid: string, { filter, sort, name }?: FamilyQuery): FamilyMember[];
export declare function pay3rdAmount(amount: number, xuid: string, xuid2: string): number[] | null;
export declare function getFamiliesNullable(xuid: string): any;
export declare function selectFamiliyMember(pl: Player): Promise<FamilyMember>;
