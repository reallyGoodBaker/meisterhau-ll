import { EventEmitter } from "events";
import { Matcher } from "@utils/matcher";
export declare const listeners: EventEmitter<[never]>;
export interface PlayerBanInfo {
    time: number;
    duration: number;
    reason: string;
}
export interface PlayerInfo {
    xuid: string;
    name: string;
    allow: boolean;
    passwd: string;
    ban?: PlayerBanInfo;
    persistent?: PersistentLogin;
}
export interface PersistentLogin {
    time: number;
    duration: number;
    ip: string;
}
export declare function createAccount(pl: Player, passwd: string, allow?: boolean): void;
export declare function activateAccount(pl: Player): void;
export declare function deactivateAccount(pl: Player): void;
export declare function verifyBanned(pl: Player): boolean;
export declare function verifyAccount(pl: Player, passwd: string): boolean | void;
export declare function updatePersistentLogin(pl: Player, duration: number, ip: string): void;
export declare function dropPersistentLogin(pl: Player): void;
export declare function verifyPersistentLogin(pl: Player): boolean;
export declare function banAccount(pl: Player, reason: string, duration?: number): boolean | undefined;
export declare function banXuid(xuid: string): void;
export declare function unbanXuid(xuid: string): void;
export declare function removeAccount(xuid: string): void;
export interface AccountFilter {
    name?: Matcher<string>;
    allow?: Matcher<boolean>;
    ban?: Matcher<Partial<PlayerBanInfo>>;
    persistent?: Matcher<PersistentLogin>;
}
export declare function selectAccount(xuid: string): PlayerInfo[];
export declare function selectAccount(filter: AccountFilter): PlayerInfo[];
export declare function selectAccountUi(operator: Player): void;
export declare function setup(): void;
