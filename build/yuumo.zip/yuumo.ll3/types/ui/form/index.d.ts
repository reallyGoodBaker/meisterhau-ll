import { FormWidget, FormView } from './core';
export declare abstract class Widget<Ctx> implements FormWidget<Ctx> {
    abstract render(): FormView<Ctx>[];
    back(pl: Player): void;
}
export declare function back(pl: Player): void;
