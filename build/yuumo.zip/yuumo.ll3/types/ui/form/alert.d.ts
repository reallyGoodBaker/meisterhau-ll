import { FormRenderer, FormView, FormWidget } from "./core";
export declare namespace Alert {
    interface AlertButton {
        text: string;
        onClick(pl: Player): void;
    }
    interface State {
        title?: string;
        content?: string;
        apply?: AlertButton;
        cancel?: AlertButton;
    }
    function Apply(text: string, onClick: (pl: Player) => void): FormView<State>;
    function Cancel(text: string, onClick: (pl: Player) => void): FormView<State>;
    function View(title: string, content: string): FormView<State>;
    const start: FormRenderer<State>;
    function back(widget: FormWidget<State>, pl: Player): void;
}
