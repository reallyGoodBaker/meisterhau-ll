export declare function Export(id: string): (target: Function) => void;
