export interface FormWidget<Ctx> {
    render(): FormView<Ctx>[];
}
export interface FormRenderer<Ctx> {
    (widget: ConstructorOf<FormWidget<Ctx>>, pl: Player): void;
}
export interface FormView<T> {
    (context: T): void;
}
export declare function getMapping(xuid: string): [string, FormWidget<any>][];
