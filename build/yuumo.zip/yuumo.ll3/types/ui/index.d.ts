export function alert(title: any, content: any, button1: any, buton2: any, onEnsure?: Function, onReject?: Function, onCancel?: Function): {
    send: any;
    open: typeof buildContextOpener;
    openAlert: (...args: any[]) => any;
    openAction: (...args: any[]) => any;
    openWidget: (...args: any[]) => any;
};
/**
 * @param {string} title
 * @param {string} content
 * @param {Array<{text: string; icon?: string; onClick: (err: any, pl: any)=>void}>} buttonGroup
 * @param {Function} onerror
 * @returns
 */
export function action(title: string, content: string, buttonGroup?: Array<{
    text: string;
    icon?: string;
    onClick: (err: any, pl: any) => void;
}>, onerror?: Function): {
    send: any;
    open: typeof buildContextOpener;
    openAlert: (...args: any[]) => any;
    openAction: (...args: any[]) => any;
    openWidget: (...args: any[]) => any;
};
export function widget(title: any, elements?: any[], onerror?: Function): {
    send: any;
    open: typeof buildContextOpener;
    openAlert: (...args: any[]) => any;
    openAction: (...args: any[]) => any;
    openWidget: (...args: any[]) => any;
};
declare function buildContextOpener(builder: any, contextSender: any, onCancelHandlerArgIndex: any): (...args: any[]) => any;
export declare let Label: (text: string) => any;
export declare let Input: (title: string, placeholder?: string, defaultVal?: string, handler?: (pl: any, value: string) => void) => any;
export declare let Switch: (title: string, defaultVal?: boolean, handler?: (pl: any, value: boolean) => void) => any;
export declare let Dropdown: (title: string, items: string[], defaultVal?: number, handler?: (pl: any, value: number) => void) => any;
export declare let Slider: (title: string, min: number, max: number, step?: number, defaultVal?: number, handler?: (pl: any, value: number) => void) => any;
export declare let StepSlider: (title: string, items: string[], defaultVal?: number, handler?: (pl: any, value: string) => void) => any;
export {};
