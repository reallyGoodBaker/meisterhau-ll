export interface PlayerInfo {
    allow: boolean;
    passwd: string;
    ban?: {
        time: number;
        duration: number;
        reason: string;
    };
}
export declare function createAccount(pl: Player, passwd: string, allow?: boolean): void;
export declare function activateAccount(pl: Player): void;
export declare function deactivateAccount(pl: Player): void;
export declare function verifyAccount(pl: Player, passwd: string): void;
export declare function banAccount(pl: Player, reason: string, duration?: number): boolean | undefined;
export declare function setup(): void;
