export declare function spawn(pos: IntPos, name: string): SimulatedPlayer | null;
export declare function despawn(pl: SimulatedPlayer): void;
export declare function listener(pl: SimulatedPlayer, listeners: {
    [k: string]: (...args: any[]) => void;
}): void;
export declare function setup(): void;
