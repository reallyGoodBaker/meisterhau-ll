export const __esModule: boolean;
export class EventEmitter {
    constructor(opt: any);
    /**@private*/ private maxListeners;
    /**@private*/ private _events;
    /**@private*/ private captureRejections;
    thisArg: {};
    setMaxListeners(size: any): this;
    getMaxListeners(): number;
    /**@private*/
    private _thisGetter;
    /**@private*/
    private _getEventLinked;
    /**@private*/
    private _canAddNew;
    /**@private*/
    private _addListener;
    addListener(type: any, handler: any): this;
    on(type: any, handler: any): this;
    prependListener(type: any, handler: any): this;
    /**@private*/
    private _removeListener;
    removeListener(type: any, handler: any): this;
    off(type: any, handler: any): this;
    removeAllListeners(type: any): void;
    /**@private*/
    private _emit;
    /**@private*/
    private _emitError;
    emit(type: any, ...args: any[]): void;
    emitNone(type: any, ...args: any[]): void;
    once(type: any, handler: any): this;
    prependOnceListener(type: any, handler: any): this;
    listenerCount(type: any): any;
    listeners(type: any): any[];
    rawListeners(type: any): any[];
    eventNames(): (string | symbol)[];
    /**@private*/
    private _enableWatcher;
    /**@private*/
    private _watcher;
    connectWatcher(watcher: any): void;
    disconnectWatcher(): void;
    /**@private*/
    private _callWatcherMethod;
}
export class BasicHook extends AbstractHook {
    call(...args: any[]): void;
    /**@private*/
    private _call;
}
export class WaterfallHook extends AbstractHook {
    call(arg: any): void;
}
export class ShortCircuitHook extends AbstractHook {
    call(...args: any[]): void;
}
export class AsyncBasicHook extends AbstractHook {
    call(...args: any[]): Promise<void>;
}
export class AsyncWaterfallHook extends AbstractHook {
    call(arg: any): Promise<void>;
}
export class AsyncShortCircuitHook extends AbstractHook {
    call(...args: any[]): Promise<void>;
}
declare class AbstractHook {
    /**@protected*/
    protected list: IndexedLinked;
    add(handler: any): this;
    remove(handler: any): boolean;
}
declare class IndexedLinked {
    constructor(thisArg?: () => {});
    thisArg: () => {};
    rawRecord: Map<any, any>;
    record: Map<any, any>;
    Entry: Linked;
    End: Linked;
    _pointer: Linked;
    size(): number;
    _recordNode(k: any, v: any): boolean;
    _recordRawNode(k: any, v: any): boolean;
    _creator(listener: any): Linked;
    _onceCreator(listener: any): Linked;
    put(listener: any): void;
    prepend(listener: any): void;
    once(listener: any): void;
    prependOnce(listener: any): void;
    deleteNode(node: any): boolean;
    delete(listener: any): boolean;
    free(): void;
    forEach(callback: any): void;
    [Symbol.iterator]: () => {
        next(): {
            value: Linked;
            done: boolean;
        };
    };
}
declare class Linked {
    prev: WillNull;
    next: WillNull;
    raw: WillNull;
    handler: WillNull;
    connect(linked: any): any;
    disconnect(): this;
    record(listener: any, raw: any): void;
}
declare class WillNull {
    static NullErr: Error;
    constructor(val: any);
    val: any;
    setValue(val: any): void;
    isNull(): boolean;
    expect(message: any): any;
    unwrap(): any;
}
export {};
