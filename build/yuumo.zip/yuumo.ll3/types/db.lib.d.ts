declare function _exports(path: any): {
    get(k: any): any;
    set(k: any, v: any): boolean;
    delete(k: any): boolean;
    listKey(): string[];
    init(k: any, defaultVal: any): any;
};
export = _exports;
